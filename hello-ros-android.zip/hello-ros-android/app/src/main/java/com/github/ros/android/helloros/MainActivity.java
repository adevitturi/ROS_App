package com.github.ros.android.helloros;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.ros.android.MessageCallable;
import org.ros.android.RosActivity;
import org.ros.android.view.RosTextView;
import org.ros.node.NodeConfiguration;
import org.ros.node.NodeMainExecutor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends RosAppCompat implements View.OnClickListener{
  private static final int SPEECH_CODE = 73;

  private Button recordingButton;
  private RosTextView<std_msgs.String> rosTextView;
  private Talker talker;

  public MainActivity() {
    super("Hello ROS", "Hello ROS");
  }

  @SuppressWarnings("unchecked")
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    recordingButton = findViewById(R.id.recording_button);
    recordingButton.setOnClickListener(this);

    rosTextView = (RosTextView<std_msgs.String>) findViewById(R.id.text);
    rosTextView.setTopicName("chatter");
    rosTextView.setMessageType(std_msgs.String._TYPE);
    rosTextView.setMessageToStringCallable(new MessageCallable<String, std_msgs.String>() {
      @Override
      public String call(std_msgs.String message) {
        return message.getData();
      }
    });
  }

  @Override
  protected void init(NodeMainExecutor nodeMainExecutor) {
    talker = new Talker("turtle1/cmd_vel");
    NodeConfiguration nodeConfiguration = NodeConfiguration.newPublic(getRosHostname());
    nodeConfiguration.setMasterUri(getMasterUri());
    nodeMainExecutor.execute(talker, nodeConfiguration);
    nodeMainExecutor.execute(rosTextView, nodeConfiguration);
  }

  @Override
  public void onClick(View v) {
    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH);


    if(intent.resolveActivity(getPackageManager())!=null) {
      startActivityForResult(intent, SPEECH_CODE);
    } else {
      Toast.makeText(this, "Speech recognition not supported on this device.", Toast.LENGTH_SHORT).show();
    }
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
    if (requestCode == MASTER_CHOOSER_REQUEST_CODE) {
      super.onActivityResult(requestCode, resultCode, data);
      return;
    }
    if(requestCode == SPEECH_CODE) {
      if(resultCode == RESULT_OK && data != null) {
        List<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        String result = results.get(0);
        Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
        try {
          String[] params = result.split(" ");
          talker.publishMessage(Integer.parseInt(params[0]),Integer.parseInt(params[0]));
          Log.e("On result", params[0] + " : " + params[1]);
        } catch (Exception e) {
          e.printStackTrace();
        }

      }
    }
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.main_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == R.id.settings) {
      Intent intent=new  Intent(getApplicationContext(),SettingsActivity.class);
      startActivity(intent);
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
}
