package com.github.ros.android.helloros;

import org.ros.concurrent.CancellableLoop;
import org.ros.internal.message.RawMessage;
import org.ros.namespace.GraphName;
import org.ros.node.AbstractNodeMain;
import org.ros.node.ConnectedNode;
import org.ros.node.NodeMain;
import org.ros.node.topic.Publisher;

import geometry_msgs.Twist;
import geometry_msgs.Vector3;

public class Talker extends AbstractNodeMain {
  private String topic_name;
  private Publisher<Twist> publisher;

  public Talker() {
    topic_name = "turtle1/cmd_vel";
  }

  public Talker(String topic)
  {
    topic_name = topic;
  }

  @Override
  public GraphName getDefaultNodeName() {
    return GraphName.of("rosjava_tutorial_pubsub/talker");
  }

  @Override
  public void onStart(final ConnectedNode connectedNode) {
    publisher = connectedNode.newPublisher(topic_name, Twist._TYPE);
//    connectedNode.executeCancellableLoop(new CancellableLoop() {
//      private int sequenceNumber;
//
//      @Override
//      protected void setup() {
//        sequenceNumber = 0;
//      }
//
//      @Override
//      protected void loop() throws InterruptedException {
//        std_msgs.String str = publisher.newMessage();
//        str.setData("Hello world! " + sequenceNumber);
//        publisher.publish(str);
//        sequenceNumber++;
//        Thread.sleep(1000);
//      }
//    });
  }

  public void publishMessage(int linearSpeed, int angularSpeed) {
    Twist cmd = publisher.newMessage();
    Vector3 linear = cmd.getLinear();
    linear.setX(linearSpeed);
    linear.setY(0);
    linear.setZ(0);
    Vector3 angular = cmd.getAngular();
    angular.setX(0);
    angular.setY(0);
    angular.setZ(angularSpeed);
    publisher.publish(cmd);
  }
}
