package com.github.ros.android.helloros;

public class RecordingInterpreter {
    private static final TargetLocation KITCHEN = new TargetLocation(10,20, 0);
    private final String payload;

    public RecordingInterpreter(String payload) {
        this.payload = payload;
    }
}
